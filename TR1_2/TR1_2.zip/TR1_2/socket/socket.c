#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#define MAX_SIZE 100000000
#define SIZE_LENTH 30  //the size of time 
#define PORT 7777
unsigned long int data_size = 1000000;

///////////// generate random data of a specific size
void buffer_generation(int size,char* data){//generate random value  as data in a size of "size"
srand((int)time(NULL));
int i = 0;
for(i=0;i<size;i++)
{
	*(data+i) = rand()%256;
}
}
void server() //consumer
{

     int sockfd, newsockfd, portno, clilen;
     struct sockaddr_in serv_addr, cli_addr;
     int n;
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = PORT;
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
     serv_addr.sin_port = htons(PORT);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0) 
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
     if (newsockfd < 0) 
          error("ERROR on accept");

     //////////////// now server can recv data
       
char *B = (char*)malloc(MAX_SIZE);
char start_tm[SIZE_LENTH] = "";
double starting_time = 0; //the time to start transfering data
int read_once = 0;
unsigned long int posi = 0;
char buffer[1000+1] = "";
while(1)
{

usleep(1);
int len = read(newsockfd,buffer,1000);//read beginning time 
//if(len>0)
//printf("recved data len %d",len);
if(!read_once && len>0&&len<=SIZE_LENTH )
{
read_once = 1;
sscanf(buffer,"%lf",&starting_time);
}
else if (len==1000)
{
memcpy(B+posi,buffer,1000);
posi=posi+1000;

if(posi==data_size)
{
//check if the size is correct and compute the time consumption and print
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double finishing_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;//  convert current time 
printf("socket data transfer costs: %.6lf second \n", (double)finishing_time - starting_time);
break;

}

}
else if (len>0) 
{
memcpy(B+posi,buffer,len);
posi = posi + len;

//check if the size is correct and compute the time consumption and print
if(posi==data_size){
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double finishing_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;//  convert current time 
printf("socket  data transfer costs: %.6lf second \n", (double)finishing_time - starting_time);
break;
}

}
}

}

void client() //producer
{
    int sockfd, portno, n;

    struct sockaddr_in serv_addr;
    struct hostent *server;
    portno = PORT;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
  
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
  //  bcopy((char *)server->h_addr, 
        // (char *)&serv_addr.sin_addr.s_addr,
       //  server->h_length);
       
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
    /////////////now procucer can send data
    

char *A = (char*)malloc(MAX_SIZE);
buffer_generation(data_size, A);
//get current time  tt
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double beginning_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;// convert current time 
char beginning_tm[SIZE_LENTH] = "";
sprintf(beginning_tm,"%.6lf",beginning_time);

unsigned  int len = write(sockfd,beginning_tm,strlen(beginning_tm)+1);//send beginning time
 if(len<0)
 printf("write err %d\n",len);
 fsync(sockfd);
unsigned long int i = 0;
unsigned long int iter = 0;
iter = data_size/1000;
if(data_size%1000 != 0)
iter++;
for(i=0;i<iter;i++)
{
usleep(1);
if(i==iter-1 && data_size%1000 != 0)
{
len = write(sockfd,A+i*1000,data_size%1000);
 if(len<0)
 printf("write err %d\n",len);
}
else
{
len = write(sockfd,A+i*1000,1000); //send data
 if(len<0)
 printf("write err %d\n",len);

}
 fsync(sockfd);

}
}


int main(int argc, char *argv[])
{
  data_size = atoi(argv[1]);
   //printf("socket recv %ld \n",data_size);
  int fork_num = -1;
  fork_num = fork();
  if(fork_num==0)
  {
  client();
  }
  else if(fork_num > 0)
  {
  server();
  }
  
 //resolve the size from argv
 //generate the data of respect to the resolved size

return 0;
}


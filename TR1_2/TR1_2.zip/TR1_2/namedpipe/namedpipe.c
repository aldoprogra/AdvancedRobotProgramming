#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <errno.h>
#include <sys/select.h>
#include <time.h>
#include <signal.h>
#include <wait.h>
#include <sys/time.h>
#define MAX_SIZE 100000000
#define SIZE_LENTH 30  //the size of time 
int P2C;
char* p_2_c = "/tmp/p2c";
unsigned long int data_size = 1000000;

///////////// generate random data of a specific size
void buffer_generation(int size,char* data){//generate random value  as data in a size of "size"
srand((int)time(NULL));
int i = 0;
for(i=0;i<size;i++)
{
	*(data+i) = rand()%256;
}
}

//////////////////////////// this is consumer 
void child_poc(){ //consumer
P2C = open(p_2_c, O_RDONLY); //open fifo
char *B = (char*)malloc(MAX_SIZE);
char start_tm[SIZE_LENTH] = "";
double starting_time = 0; //the time to start transfering data
int read_once = 0;
unsigned long int posi = 0;
char buffer[1000+1] = "";
while(1)
{

usleep(1);
int len = read(P2C,buffer,1000);//read beginning time 
if(len>0)
//printf("recved data len %d",len);
if(!read_once && len>0&&len<=SIZE_LENTH )
{
read_once = 1;
sscanf(buffer,"%lf",&starting_time);
}
else if (len==1000)
{
memcpy(B+posi,buffer,1000);
posi=posi+1000;

if(posi==data_size)
{
//check if the size is correct and compute the time consumption and print
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double finishing_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;//  convert current time 
printf("\nnamed pipe data transfer costs: %.6lf second \n", (double)finishing_time - starting_time);
fflush(stdout);
break;

}

}
else if (len>0) 
{
memcpy(B+posi,buffer,len);
posi = posi + len;

//check if the size is correct and compute the time consumption and print
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double finishing_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;//  convert current time 
printf("\nnamed pipe data transfer costs: %.6lf second \n", (double)finishing_time - starting_time);
fflush(stdout);
break;
}
}



}

///////////////////////// this is producer
void parent_proc(){ 
P2C = open(p_2_c, O_WRONLY); //open fifo
char *A = (char*)malloc(MAX_SIZE);
buffer_generation(data_size, A);

//get current time  tt
struct timespec time_1;
clock_gettime(CLOCK_REALTIME, &time_1);//check current time 
double beginning_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;// convert current time 
char beginning_tm[SIZE_LENTH] = "";
sprintf(beginning_tm,"%.6lf",beginning_time);

unsigned  int len = write(P2C,beginning_tm,strlen(beginning_tm)+1);//send beginning time
if(len<0)
printf("write err %d\n",len);
fsync(P2C);
int i = 0;
int iter = 0;
iter = data_size/1000;
if(data_size%1000 != 0)
iter++;
for(i=0;i<iter;i++)
{
usleep(1);
if(i==iter-1 && data_size%1000 != 0)
{
len = write(P2C,A+i*1000,data_size%1000);
 if(len<0)
 printf("write err %d\n",len);
  fsync(P2C);
}
else
{
len = write(P2C,A+i*1000,1000); //send data
 if(len<0)
 printf("write err %d\n",len);
 fsync(P2C);
}


}

}

int main(int argc, char *argv[])
{
 data_size = atoi(argv[1]);
 //printf("named pipe recv %ld \n",data_size);
  mkfifo(p_2_c, 0666);
  int fork_num = -1;
  fork_num = fork();
  if(fork_num==0)
  {
  child_poc();
  }
  else if(fork_num > 0)
  {
  parent_proc();
  }
  
  //resolve the size from argv
 //generate the data of respect to the resolved size

return 0;
}

#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <errno.h>
#include <sys/select.h>
#include <time.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <math.h>

#define MSGSIZE 50
#define SHM_KEY 0x1234
#define MAX_SIZE 100000000

unsigned long int choice , SIZE ,  SIZECB;
size_t npage_size;

/*      LOG FUNCTION    */

void post_log(char* data,int size)
{   
    int fd_log;

    fd_log = open("TR1_2/log/log_master.txt",O_APPEND|O_WRONLY|O_CREAT);
    if(fd_log < 0){
        printf("fd_log open error");
        fflush(stdout);
    
    if(size>50){
        printf("log_size_overflow:%s\n ",data);
        fflush(stdout);}

    }else{
        char logmsg[72] = "";
        unsigned int log_time = time(NULL);
        sprintf(logmsg,"info:%s,time:%d\n",data,log_time);
        write(fd_log,logmsg,strlen(logmsg));
        close(fd_log);
    }
}



int main(){

    char* myfifo = "/tmp/myfifo";
    mkfifo(myfifo, 0666);
    int fd = open(myfifo , O_RDWR);
    if (fd == -1){perror("fd");}



    while(1){

        printf("    Choose which program run :  \n");
        fflush(stdout);

        printf("1- Named pipe\n2- Unnamed pipes\n3- Sockets\n4- Shared memory and circular buffer\n");
        fflush(stdout);

        scanf("%d", &choice);

        printf("     Set the number of bytes stored in the array A and B :\n");
        fflush(stdout);
        scanf("%ld", &SIZE);
	if(SIZE>100000000) { 
		printf("size should be smaller than 100,000,000\n"); 
		fflush(stdout); 		
		continue; }




        /* Option for kill process and run another scenario */

        if (choice == 1){
            pid_t namedpipe = fork();
            if(namedpipe == 0){
                // SON CODE 
        char size_str[20]  ="";
 	sprintf(size_str,"%ld",SIZE);
	char* argument_list[3] = {"./namedpipe", NULL, NULL}; // NULL terminated array of char* strings
	argument_list[1] = size_str;
	execvp("./namedpipe", argument_list);
        perror("execv"); 
            }
            if(namedpipe > 0){
                int stat = wait(NULL);
                if(stat == (pid_t)-1){
                    perror("wait");
                }
            }

            if(namedpipe < 0){
                perror("fork");}
        }

        else if (choice == 2){
        
          pid_t unnamedpipe = fork();
            if(unnamedpipe == 0){

                // SON CODE 
        char size_str[20]  ="";
 	sprintf(size_str,"%ld",SIZE);
	char* argument_list[3] = {"./unnamedpipe", NULL, NULL}; // NULL terminated array of char* strings
	argument_list[1] = size_str;
	execvp("./unnamedpipe", argument_list);
	
        perror("execv"); 
            }
            if(unnamedpipe > 0){
                int stat = wait(NULL);
                if(stat == (pid_t)-1){
                    perror("wait");
                }
            }

            if(unnamedpipe < 0){
                perror("fork");}
        }

        else if (choice == 3){
        
                  pid_t socket = fork();
            if(socket == 0){

                // SON CODE 
	char size_str[20]  ="";
 	sprintf(size_str,"%ld",SIZE);
	char* argument_list[3] = {"./socket", NULL, NULL}; // NULL terminated array of char* strings
	argument_list[1] = size_str;
	execvp("./socket", argument_list);
	
        perror("execv"); 
            }
            if(socket > 0){
                int stat = wait(NULL);
                if(stat == (pid_t)-1){
                    perror("wait");
                }
            }

            if(socket < 0){
                perror("fork");}
        }

        // PROCESS WITH SHARED MEMORY
        else if (choice == 4){

	   /*  Dimension Circular buffer   */

	   printf ("       Set the number of bytes of the circular buffer:\n");
	   fflush(stdout);
	   scanf("%d", &SIZECB);


            /*  SHARED MEMORY  */

            void *buff;

            // Get time
	    char *A = (char*)malloc(MAX_SIZE);
	    memset(A,'A',MAX_SIZE);
            struct timespec time_1;
            clock_gettime(CLOCK_REALTIME, &time_1);     //check current time 
            double starting_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;


            // open shm

            int fp = shm_open("/fuerteventura",O_RDWR |O_TRUNC | O_CREAT | O_NONBLOCK,S_IRUSR | S_IWUSR );
            if (fp > 0 ){
                post_log("shm_open success", strlen("shm_open success"));
                }

            // Sending info
            char output[MSGSIZE] = "";
            sprintf(output,"%ld,%d,%lf,%d", SIZE, SIZECB , starting_time,fp);
            if(write(fd, output , strlen(output) +1 ) > 0 ){
                fsync(fd);
                post_log(output, strlen(output));
                }

            if((ftruncate(fp, SIZE)) == -1){   
                perror("ftruncate failure");
                exit(0);

              } 
            
            post_log("Ftruncate success", strlen("Ftruncate success"));
            
            
            buff = (void *) mmap(NULL ,SIZE , PROT_READ |PROT_WRITE, MAP_SHARED| MAP_POPULATE,fp, 0);
            if(buff == MAP_FAILED){perror("Mmap failed in mast:");}
           
           
            post_log("mmap success", strlen("mmap success"));
            // Writing block of data with a buffer of varable size
            // Doesn't matter which type data, 

            memcpy((char *) buff,A, SIZE);
            printf("Writing process, I have written: %ld bytes\n",strlen(buff));
            fflush(stdout);
            post_log("I have written in the shared memory", strlen("I have written in the shared memory")+1);
            msync(buff, SIZE, MS_SYNC);
            munmap(buff , SIZE);
            /*  Fork   */

            pid_t shmemory = fork();
            if(shmemory == 0){

                // SON CODE 

                char  * argv[2] = {"./shmemory/", 0};
                execvp("./shmemory", argv);
                perror("execv");
                
            }
            if(shmemory > 0){

                int stat = wait(NULL);
                if(stat == (pid_t)-1){
                    perror("wait");
                }
           

            }

            if(shmemory < 0){
                perror("fork");}
           

       }
       
    sleep(1);
    }  } 

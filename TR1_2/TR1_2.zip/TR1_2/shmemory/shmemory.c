#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <errno.h>
#include <sys/select.h>
#include <time.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define MSGSIZE 1000
#define SHM_KEY 0x1234
#define MAX_SIZE 100000000

// Function for post log data inside txt

void post_log(char* data,int size)
{
    int fd_log;
    if(size>50){
        printf("log_size_overflowshmem:%s\n ",data);
        fflush(stdout);}
    fd_log = open("TR1_2/log/log_shm.txt",O_APPEND|O_WRONLY|O_CREAT);
    if(fd_log ==-1){
        printf("fd_log open error");
        fflush(stdout);
    }else{
        char logmsg[72] = "";
        unsigned int log_time = time(NULL);
        sprintf(logmsg,"info:%s,time:%d\n",data,log_time);
        write(fd_log,logmsg,strlen(logmsg));
        close(fd_log);
    }
}

typedef struct {
    char *values ;   /* store values */
    int head, tail, num_entries, size;
}queue;

// initialisation of the queue

void init_queue(queue *q, int max_size){
    q-> size = max_size;
    q-> values = malloc(q-> size);
    q-> num_entries = 0;
    q-> head = 0 ;
    q-> tail = 0 ;
}

// Is the queue empty?

int  queue_empty (queue * q ){
    if(q -> num_entries == 0){
        printf("EMPTY\n");
        fflush(stdout);
        return (0);
    }else{
        return (1);}
}

// Is the queue full?
int queue_full (queue * q ){
    if (q -> num_entries == q -> size){
        printf("FULL");
        fflush(stdout);
        return (0);
    }else{
        return (1);}}


// Function for enter items in the queue 

int enqueue (queue * q , char value){  
    if (queue_full(q) == 0 ){        
        printf("FULL\n");
        fflush(stdout);      /*add item in the queue*/
        return (0);
    }    
    q -> values[q -> tail] = value;
    q-> num_entries ++;
    q-> tail = (q->tail +1) % (q->size);
    return (1);
}

// Free the memory from the data

void queue_destroy (queue *q){
    free(q-> values);
}

// Read function

char dequeue(queue * q){
    char result;
    if(queue_empty(q) == 0){
        printf("EMPTY\n");
        fflush(stdout);
        return (1);
    }
    result = q -> values[q->head];
    q->head = (q->head +1) % (q->size);
    q-> num_entries -- ;

    return result;

}

char* myfifo = "/tmp/myfifo";

int main(){

    mkfifo(myfifo,0666);  

    int fd = open(myfifo, O_RDONLY);

    if(fd == -1){
        perror("open");
    } 

    //post_log("SONO", 5);
    // Pipe for transferring size of array and of the circular buffer

    unsigned long int t,SIZE;
    int SIZECB,fp;
    double starting_time;


    /* Read size from the pipe */

    post_log("before reading", strlen("before reading"));
    char input_string[MSGSIZE] = "";
    read(fd,input_string, MSGSIZE);
    post_log(input_string, strlen(input_string));
    sscanf(input_string,"%ld,%d,%lf,%d", &SIZE , &SIZECB, &starting_time, &fp );
    //printf("fp = %d\n", fp);
    fflush(stdout);

    /* Initialisation circular buffer */

    queue CB;
    init_queue(&CB, SIZECB);

    //PASSING DATA FROM SHARED MEMORY TO ARRAY THROUGH CIRCULAR BUFFER


    int fp1 = shm_open("/fuerteventura",O_RDWR,0777);
    if ( fp1 < 0){perror("shmemopen fail");};
    //printf("fp1 = %d\n", fp1);


    void * buff = (void *) mmap( NULL , SIZE , PROT_READ |O_NONBLOCK , MAP_SHARED, fp1, 0);
    if (buff == MAP_FAILED){
        perror("mmap failed");}

    post_log("after mmap", strlen("after mmap"));


    // Read memory buffer 
    

    printf("In memory there are %ld bytes readable\n", strlen(buff));
    fflush(stdout);

    // array to fill
    char *B = (char*)malloc(SIZE);
    memset(B,0,SIZE);
    unsigned long int i  = 0;

    while(i != SIZE)
    {
        //printf("%c", * (char *) buff);
        enqueue(&CB,  *(char *) buff);
        //printf("CB: I wrote %c in position %d and i = %d\n", CB.values[CB.tail-1], CB.tail, i);
        //fflush(stdout);
        
        B[i] = dequeue(&CB);    // Could  return error number and fill inside.
        //printf("I read %ls in position %d", CB.values, CB.head);
        fflush(stdout);

        //printf("I have read:%c\n", resulted[i]);
        //printf("should have read: %c\n",* (char *) buff);
        //fflush(stdout);
        i++;
        buff++;
    
    }
 
    printf("I successfully stored %ld bytes in one array with the CB\n",strlen(B));
    fflush(stdout);
    post_log("finihed", strlen("finished"));
    queue_destroy(&CB);
   
    

    // Get time

    struct timespec time_1;
    clock_gettime(CLOCK_REALTIME, &time_1);     //check current time 
    double final_time  = (double)time_1.tv_sec + (double)time_1.tv_nsec/1000000000;

    printf("TIME: %f seconds\n", final_time - starting_time);
    fflush(stdout);

    sleep(3);

  

  

   exit(0);

}



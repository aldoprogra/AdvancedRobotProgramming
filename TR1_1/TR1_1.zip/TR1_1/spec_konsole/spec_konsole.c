#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <signal.h>
#define MSGSIZE 16

struct timeval time_for_ms;
void sleep_ms(unsigned int n)
{

 time_for_ms.tv_sec = 0;
      time_for_ms.tv_usec = n*1000;

      int ready = select(NULL, NULL, NULL, NULL, &time_for_ms);
}


char* log_file = "TR1_1/log/logARP1_spec.txt"; 
void post_log(char* data,int size)
{
if(size>50)
printf("log_size_overflow:%s\n ",data);
int fd_log = open(log_file,O_APPEND|O_WRONLY|O_CREAT);
if(fd_log ==-1)
{
  printf("fd_log open error");
  /* code */
}
else
{
 char logmsg[72] = "";
 unsigned int log_time = time(NULL);
 sprintf(logmsg,"info:%s,time:%d\n",data,log_time);
write(fd_log,logmsg,strlen(logmsg));
close(fd_log);
}
}

int w2spec;
//message coming from the watchdog
char input_string[MSGSIZE];

  char* w_spec = "/tmp/w2spec";
  char* spec_w = "/tmp/spec2w";//"/root/Desktop/ARP/named_pipe/myfifo";//
  char* myfifo_w_spec_pid = "/tmp/w2spec_pidx"; 
  char* myfifo_motorz_spec = "/tmp/motorz2spec"; 
  char* myfifo_motorx_spec = "/tmp/motorx2spec"; 
  
void print_screen()
{
	printf("\033[2J");
        printf("\n\t\t\tINSPECTION KONSOLE\n\n\n\n\n");


	printf("\n\t\t\t\tpress:\n\n\n");

	printf("\n\t\treset: R\t\tstop: S");
	printf("\n\n\n\n\n\n");
	printf("\r              x_axis: %.2f  z_axis: %.2f     ",0,0);

        fflush(stdout);

}

int main(){

 char read_buffer_w[MSGSIZE] = "";
 char read_buffer_motorx[MSGSIZE] = "";
 char read_buffer_motorz[MSGSIZE] = "";
 char input_command;
 char tmp_str[10] = "";
 float real_position_x = 0;
 int position_estimated_x = 0; // for postion
 float real_position_z = 0;
 int position_estimated_z = 0;
 int running = 1;

fd_set rfds_motor;               // for select receiving position
struct timeval tv_motor;
int retval_motor, m_motor,n_motor;
int select_maxfd_motor = 0;

fd_set rfds_cmmd;
struct timeval tv_cmmd;
int retval_cmmd;


int motorx_2_spec = -1; //FD
int motorz_2_spec = -1;
int spec2w = -1;
int w2spec = -1;
mkfifo(w_spec, 0666); 
mkfifo(spec_w, 0666);
mkfifo(myfifo_w_spec_pid, 0666);    //tell spec the pid of motiors and motorz
mkfifo(myfifo_motorz_spec, 0666); // for motors receiving cmmd
mkfifo(myfifo_motorx_spec, 0666);    //tell spec the pid of motiors and motorz
int w_spec_pid_fd = open(myfifo_w_spec_pid, O_RDONLY);   
spec2w = open(spec_w, O_WRONLY|O_NONBLOCK);                   // set nonblock
w2spec = open(w_spec, O_RDONLY|O_NONBLOCK);  
motorx_2_spec = open(myfifo_motorx_spec,O_RDONLY|O_NONBLOCK);
motorz_2_spec = open(myfifo_motorz_spec,O_RDONLY|O_NONBLOCK); 



      ////////////// preparing pid of motors//////////////////////////////////////
    char pids[MSGSIZE] = "";

    read(w_spec_pid_fd, pids, MSGSIZE);
    post_log("recved pid", sizeof("recved pid"));
    post_log(pids, strlen(pids));

    
    // close(w_spec_pid_fd);
  int pid_motox = -1;
  int pid_motoz = -1;
  sscanf(pids,"%d;%d",&pid_motox,&pid_motoz);
    ////////////// prepared pid of motors//////////////////////////////////////

print_screen();


while(running)
{

if(spec2w<=0)  
spec2w = open(spec_w, O_WRONLY|O_NONBLOCK);                   // set nonblock
if(w2spec<=0)
w2spec = open(w_spec, O_RDONLY|O_NONBLOCK);  
if(motorx_2_spec<=0)
motorx_2_spec = open(myfifo_motorx_spec,O_RDONLY|O_NONBLOCK);
if(motorz_2_spec<=0)
motorz_2_spec = open(myfifo_motorz_spec,O_RDONLY|O_NONBLOCK); 





sleep_ms(10);

 // 0 tell watch_dog I am working by named_fifo  w_spec

    write(spec2w, "w", sizeof("w"));
   // close(spec2w);

 // 1 check if we need reset by watch_dog
   read_buffer_w[0] = 0;
   fcntl(w2spec,F_SETFL,FNDELAY);  
    read(w2spec, read_buffer_w, MSGSIZE);
   // close(w2spec);
   if(read_buffer_w[0] !=0)
   if(read_buffer_w[0]=='r')
   {
      // run reset code 
      real_position_x = 0;
      position_estimated_x = 0;
      real_position_z = 0;
      position_estimated_z = 0;
      continue;
   }
   else if(read_buffer_w[0]=='k') //kill
   {
   
    running = 0;
    continue;
   }
   


   
   //read command from console

FD_ZERO(&rfds_cmmd);
FD_SET(0, &rfds_cmmd);
/* Wait up to five seconds. */
tv_cmmd.tv_sec = 0;
tv_cmmd.tv_usec = 10;
retval_cmmd = select(1, &rfds_cmmd, NULL, NULL, &tv_cmmd);//mafd+1, readfds,writefds,errfds,timeval
if (retval_cmmd == -1)
perror("select()");
else if (retval_cmmd>0) {
/* FD_ISSET(0, &rfds) will be true. */
//n = read(0, line, 80);
   printf("\033[1A");
   post_log("recving_RS",sizeof("recving_RS"));
   tmp_str[0]=0;
   fgets(tmp_str, sizeof(tmp_str), stdin);
   post_log(tmp_str,strlen(tmp_str));
   input_command = tmp_str[0];
   if (input_command == 'R')
   {
   // recover motor
   kill(pid_motox, SIGUSR2);
   kill(pid_motoz, SIGUSR2);
   
   }
   if (input_command == 'S')
   {
   //signal stop motor
   kill(pid_motox, SIGUSR1);
   kill(pid_motoz, SIGUSR1);
   }
   
}
   
   
/* Watch stdin (fd 0) to see when it has input. */
FD_ZERO(&rfds_motor);

FD_SET(motorx_2_spec, &rfds_motor);
FD_SET(motorz_2_spec, &rfds_motor);

if(motorx_2_spec > motorz_2_spec)
select_maxfd_motor = motorx_2_spec;
else select_maxfd_motor = motorz_2_spec;
/* Wait up to 30 miliseconds. */
tv_motor.tv_sec = 0;
tv_motor.tv_usec = 50*1000;
retval_motor = select(select_maxfd_motor+1, &rfds_motor, NULL, NULL, &tv_motor);//mafd+1, readfds,writefds,errfds,timeval
// return value: the number of fds that received a event
/* Don’t rely on the value of tv now! */
if(retval_motor==0)
{
post_log("time out ",sizeof("time out "));
}
if (retval_motor == -1)
perror("select()");
{ //data is availale


post_log("recvedMotorPosi",sizeof("recvedMotorPosi"));
//4. read data from motorx and motorz and show////////////////////////////////////xxzxzxzxzxzxzxzxzxzxzxzxz
if(read(motorx_2_spec,read_buffer_motorx,MSGSIZE)>0)//moter x is ready
{
sscanf(read_buffer_motorx,"%d",&position_estimated_x);
real_position_x = (float)position_estimated_x/100;
printf("\r              x_axis: %.2f  z_axis: %.2f     ",real_position_x,real_position_z);
fflush(stdout);	
}
if(read(motorz_2_spec,read_buffer_motorz,MSGSIZE)>0)
{
sscanf(read_buffer_motorz,"%d",&position_estimated_z);
real_position_z = (float)position_estimated_z/100;
printf("\r              x_axis: %.2f  z_axis: %.2f     ",real_position_x,real_position_z);

fflush(stdout);	
}
		
}
//close(motorx_2_spec);
//close(motorz_2_spec);


}
}



#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <errno.h>
#include <sys/select.h>
#include <time.h>
#include <signal.h>
#include <wait.h>
#define MSGSIZE 16
#define X_MAX 10*100
#define X_MIN 0
#define Z_MAX 0
#define Z_MIN -2000  //accul
#define SPEED 1
#define DT X_MAX/(100*SPEED) //ms
#define STEP 1//(SPEED/1000)*DT
int running = 1;
int motor_running = 1;
int spec_reset = 0;
int after_reset = 0;
char input_string[5];
char* log_file = "TR1_1/log/logARP1_watchdog.txt"; 

struct timeval time_for_ms;
void sleep_ms(unsigned int n)
{

 time_for_ms.tv_sec = 0;
      time_for_ms.tv_usec = n*1000;

      int ready = select(NULL, NULL, NULL, NULL, &time_for_ms);
}
void handler_motor_stop (int signal_number)
 {
 
 post_log("called S", strlen("called S"));
 printf("called stop");
  if(SIGUSR1 == signal_number)
  motor_running = 0;
 
 } 

 void handler_motor_recover (int signal_number)//R
 {
    post_log("called R", strlen("called R"));
    if(SIGUSR2 == signal_number){
      printf("called reset");
      fflush(stdout);
      motor_running = 1;
      spec_reset = 1;
      
    }
 }  

void post_log(char* data,int size)
{
if(size>50)
printf("log_size_overflow:%s\n ",data);
int fd_log = open(log_file,O_APPEND|O_WRONLY|O_CREAT);
if(fd_log ==-1)
{
  printf("fd_log open error");
  /* code */
}
else
{
 char logmsg[72] = "";
 unsigned int log_time = time(NULL);
 sprintf(logmsg,"info:%s,time:%d\n",data,log_time);
write(fd_log,logmsg,strlen(logmsg));
 close(fd_log);
}
}


int watchdog(){

post_log("entering wd",sizeof("entering wd"));
  //Creating four unamed pipes
  // Watchdog -----> motor_x and otherwise {motorx_2_w, w_2_motorx}
  // Watchdog -----> motor_z and otherwise {motorz_2_w, w_2_motorz}

  int motorx_2_w[2];
  int motorz_2_w[2];
  int w_2_motorx[2];
  int w_2_motorz[2];

  pipe(motorx_2_w);
  pipe(motorz_2_w);
  pipe(w_2_motorx);
  pipe(w_2_motorz);

  //four named pipes: 
  //watchdog --> spec_konsole  and otherwise {w2spec, spec2w}
  //watchdog --> command_konsole and otherwise {w2comm, comm2w}

  int w2spec;
  int spec2w;
  int w2cmmd;
  int cmmd2w;

  char* w_spec = "/tmp/w2spec";
  char* spec_w = "/tmp/spec2w";
  char* w_cmmd = "/tmp/w2cmmd";
  char* cmmd_w = "/tmp/cmmd2w"; 
  char* myfifo_cmmd_motorz = "/tmp/cmmd2motorz"; 
  char* myfifo_cmmd_motorx = "/tmp/cmmd2motorx"; 
  char* myfifo_w_spec_pid = "/tmp/w2spec_pidx"; 
  char* myfifo_motorz_spec = "/tmp/motorz2spec"; 
  char* myfifo_motorx_spec = "/tmp/motorx2spec"; 

  mkfifo(w_spec, 0666);
  mkfifo(spec_w, 0666);
  mkfifo(w_cmmd, 0666);
  mkfifo(cmmd_w, 0666);
  mkfifo(myfifo_cmmd_motorz, 0666);
  mkfifo(myfifo_cmmd_motorx, 0666); // for motors receiving cmmd
  mkfifo(myfifo_w_spec_pid, 0666);    //tell spec the pid of motiors and motorz

  mkfifo(myfifo_motorz_spec, 0666); // for motors receiving cmmd
  mkfifo(myfifo_motorx_spec, 0666);    //tell spec the pid of motiors and motorz



  //time

  struct timeval timeout;


  //Creating the two processes

  pid_t motor_x;
  motor_x = fork();
  printf("motor_x %d",motor_x);
  fflush(stdout);
  if (motor_x > 0) {
    post_log("father x",sizeof("father x"));
    pid_t motor_z = fork();
    printf("motor_z %d",motor_z);
    fflush(stdout);
    if (motor_z > 0)
    { //father code  here is watch_dog
    post_log("father z",sizeof("father z"));
      ////////////// tell spec the pid of motors//////////////////////////////////////
    char pids[20] = "";
    sprintf(pids,"%d;%d",motor_x,motor_z);
    post_log("sending pid", strlen("sending pid"));
    

    int w_spec_pid_fd = open(myfifo_w_spec_pid, O_WRONLY);                      // set nonblock
    write(w_spec_pid_fd, pids, strlen(pids));
    //close(w_spec_pid_fd);
    post_log(pids, strlen(pids));
    post_log("sent pid", strlen("sent pid"));
      ////////////////////////////////////////////////////////////////////////////////
    spec2w = open(spec_w, O_RDONLY|O_NONBLOCK);
    cmmd2w = open(cmmd_w, O_RDONLY|O_NONBLOCK);
    w2spec = open(w_spec, O_WRONLY|O_NONBLOCK);
    
    
    char tem_w_data[MSGSIZE] = "";
    while (1){   // code of watch dog
    if(spec2w<=0)
    spec2w = open(spec_w, O_RDONLY|O_NONBLOCK);
    if(cmmd2w<=0)
    cmmd2w = open(cmmd_w, O_RDONLY|O_NONBLOCK);
    if(w2spec<=0)
    w2spec = open(w_spec, O_WRONLY|O_NONBLOCK);
    
    
    
      sleep_ms(1);
     //  post_log("wd_running", strlen("wd_running"));
      // Preparing sets for select function
      int nfds = 1024; //I take the highest value of fd 
      fd_set readfds;
      fd_set writefds;
      FD_ZERO(&readfds);
      FD_ZERO(&writefds);
     
     // comment this part and change the value of timeout to test watch-dog "reset" function
      FD_SET(spec2w,&readfds);
      FD_SET(cmmd2w,&readfds);
      FD_SET(motorx_2_w[0],&readfds);
      FD_SET(motorx_2_w[0],&readfds);

      // select must watch if motorx,motorz,comm_konsole 
      // or spec_konsole have written something within 60 seconds
      timeout.tv_sec = 60;
      timeout.tv_usec = 0;

      int ready = select(1024, &readfds, NULL, NULL, &timeout);
      if(ready>0) //clen all the data if received
      {
        
         
         if(FD_ISSET(motorx_2_w[0], &readfds))//moter x is ready
            {
              read(motorx_2_w[0],tem_w_data,MSGSIZE);
            }
          if(FD_ISSET(motorz_2_w[0], &readfds))//moter x is ready
            {
              read(motorz_2_w[0],tem_w_data,MSGSIZE);
            }
          if(FD_ISSET(spec2w, &readfds))//moter x is ready
            {
              read(spec2w,tem_w_data,MSGSIZE);
            }
          if(FD_ISSET(cmmd2w, &readfds))//moter x is ready
            {
              read(cmmd2w,tem_w_data,MSGSIZE);
            }
            
 	//post_log(tem_w_data, strlen(tem_w_data));
     //close(spec2w);
      //close(cmmd2w);
      continue;


      }
      if (ready == -1){
        perror("select()");
        fflush(stdout);
      }
      if (ready == 0) {

            printf("No data within sixty seconds, resetting ..\n");
            fflush(stdout);
            
            // writing on spec_konsole
            write(w2spec, "r", strlen("r")+1);
            fsync(w2spec);
          //close(w2spec);

            // writing on motor_x

            write(w_2_motorx[1], "r" , strlen("r") + 1 );
            fsync(w_2_motorx[1]);
            // writing on motorz
            write(w_2_motorz[1], "r" , strlen("r") + 1 );
            fsync(w_2_motorz[1]);
          }
     //close(spec2w);
     //close(cmmd2w);
    
    } //end code of wd
     

  } //end of father code x father
  
    if (motor_z == 0){//code of motorz
    printf("motorz running \n");
    fflush(stdout);
post_log("motorz running", strlen("motorz running"));
////////////////////////////////zzzzzzzzzzzzzzzzzzzzzzzzzzz/////////////////





struct sigaction sa;
/* set sa to zero using the memset() C library function */
/* set signal function*/
memset(&sa, 0, sizeof(sa));           
sa.sa_handler = &handler_motor_stop;     
sigaction (SIGUSR1, &sa, NULL);
memset(&sa, 0, sizeof(sa));
sa.sa_handler = &handler_motor_recover;
sigaction (SIGUSR2, &sa, NULL);

 int cmmd2motorz = open(myfifo_cmmd_motorz, O_RDONLY|O_NONBLOCK);
 int motorz2spec = open(myfifo_motorz_spec, O_WRONLY|O_NONBLOCK);


 char read_buffer_w[MSGSIZE] = "";
 char read_buffer_cmmd[MSGSIZE] = "";
 char write_buffer_spec[MSGSIZE] = "";
 char command,last_command;
 int position = 0;
 float real_position = 0;
 int position_estimated = 0;
 int err_ = 0;
 unsigned int rand_dt = 0;	
while(running)
{
if(cmmd2motorz <= 0)
  cmmd2motorz = open(myfifo_cmmd_motorz, O_RDONLY|O_NONBLOCK);
if(motorz2spec <= 0)
  motorz2spec = open(myfifo_motorz_spec, O_WRONLY|O_NONBLOCK);



//post_log("motorz running", strlen("motorz running"));

sleep_ms(DT);


 // 0 tell watch_dog I am working by named_fifo  w_spec
 
 write(motorz_2_w[1], "w", sizeof("w"));
 //post_log("told wd motorz", strlen("told wd motorz"));
 // 1 check if we need reset by watch_dog
   read_buffer_w[0] = 0;
   fcntl(w_2_motorz[0],F_SETFL,FNDELAY);          //set nonblock
   read(w_2_motorz[0], read_buffer_w, MSGSIZE);

   if(read_buffer_w[0]!=0||spec_reset==1)
   if(read_buffer_w[0]=='r'||spec_reset==1)
   {
    // run reset code 
    spec_reset = 0;
    after_reset = 1;
    position = 0;
    real_position = 0;
    position_estimated = 0;
    err_ = 0;
    rand_dt = 0;
  
  
   }
   if(read_buffer_w[0]=='k') //kill
   {
   
   running = 0;
    continue;
   }
   
 
 // read command from cmmd_console  unnamed pipe
    read_buffer_cmmd[0] = 0;
    fcntl(cmmd2motorz,F_SETFL,FNDELAY);                         // set nonblock
    read(cmmd2motorz, read_buffer_cmmd, MSGSIZE);
    //close(cmmd2motorz);

    command = read_buffer_cmmd[0];
    if(command != 0)  //if read nothing, keep last cmmd
    {
    	last_command = command;
    	post_log("recv new cmmd", strlen("recv new cmmd"));
    		//printf("new cmmdx :%c",command);
    		fflush(stdout);
    }
    else
    {
    command = last_command;
    
    }
    if(after_reset == 1)
    {
    after_reset=0;
    command = last_command = 's';
    
    }
    	//up u
	if(command == 'j' && (position < Z_MAX) )
	{
	if(motor_running)
	{
	
	position += STEP;
	real_position = (float)position/100;
	rand_dt += (int)time(NULL);
	srand((int)time(NULL)*time(NULL)+rand_dt);
	err_ = rand()%5-2;
	position_estimated = position + err_;
	
	}
	sprintf(write_buffer_spec,"%d",position_estimated);
	write(motorz2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	//printf("write: %s\n",write_buffer_spec);
	}
	// down d
	if(command == 'l' && (position > Z_MIN) )
	{
	if(motor_running)
	{
	position -= STEP;
	real_position = (float)position/100;
	rand_dt += (int)time(NULL);
	srand((int)time(NULL)*time(NULL)+rand_dt);
	err_ = rand()%5-2;
	
	position_estimated = position + err_;}
	sprintf(write_buffer_spec,"%d",position_estimated);
	write(motorz2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	//printf("write: %s\n",write_buffer_spec);

	}
	// stop s
	if(command == 's' )
	{
	position_estimated = position;
	sprintf(write_buffer_spec,"%d",position_estimated);
  write(motorz2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	//printf("write: %s\n",write_buffer_spec);
  fflush(stdout);
	}
	  //tell spec the postion of motors
  
   	//close(motorz2spec);
	//<send estimate position>

} //end motorz loop



    }//end of if motorz

    if (motor_z == -1){
    printf("fork_err_motorz");
    fflush(stdout);

      perror("forkz");
      exit(-1);
    }

   //---- CODE OF MOTOR_X ------
////////////////////////////////xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/////////////////


 
}
if (motor_x == -1){
	printf("fork_motorx_err");
	fflush(stdout);

    perror("forkx");
    exit(-1);
}
if (motor_x == 0 ) {
printf("motorx_running \n");
fflush(stdout);
post_log("x_running ",sizeof("x_running "));
struct sigaction sa;
/* set sa to zero using the memset() C library function */
memset(&sa, 0, sizeof(sa));
sa.sa_handler = &handler_motor_stop;
sigaction (SIGUSR1, &sa, NULL);

memset(&sa, 0, sizeof(sa));
sa.sa_handler = &handler_motor_recover;
sigaction (SIGUSR2, &sa, NULL);


 char read_buffer_w[MSGSIZE] = "";
 char read_buffer_cmmd[MSGSIZE] = "";
 char write_buffer_spec[MSGSIZE] = "";
  char command1,last_command1;
 int position = 0;
 float real_position = 0;
 int position_estimated = 0;
 int err_ = 0;
 unsigned int rand_dt = 0;
 int cmmd2motorx = open(myfifo_cmmd_motorx, O_RDONLY|O_NONBLOCK);
 int motorx2spec = open(myfifo_motorx_spec,O_WRONLY|O_NONBLOCK);	
while(running)
{
if(motorx2spec<=0)
  motorx2spec = open(myfifo_motorx_spec,O_WRONLY|O_NONBLOCK);
if(cmmd2motorx<=0)
  cmmd2motorx = open(myfifo_cmmd_motorx, O_RDONLY|O_NONBLOCK);

 sleep_ms(DT);

if(!motor_running)
{
continue;
}

 // 0 tell watch_dog I am working by named_fifo  w_spec
 write(motorx_2_w[1], "w", sizeof("w"));

 // 1 check if we need reset by watch_dog
   read_buffer_w[0] = 0;
   fcntl(w_2_motorx[0],F_SETFL,FNDELAY);          //set nonblock
   read(w_2_motorx[0], read_buffer_w, MSGSIZE);
   if(read_buffer_w[0] !=0 || spec_reset==1)
   if(read_buffer_w[0]=='r'|| spec_reset==1)
   {
  // run reset code 
  spec_reset = 0;
  after_reset = 1;
  position = 0;
  real_position = 0;
  position_estimated = 0;
  err_ = 0;
   rand_dt = 0;

   }
   if(read_buffer_w[0]=='k')
   {
   
   running = 0;
    continue;
   }
   
   
 // read command
    read_buffer_cmmd[0] = 0;
    fcntl(cmmd2motorx,F_SETFL,FNDELAY);                         // set nonblock
    read(cmmd2motorx, read_buffer_cmmd, MSGSIZE);
     //close(cmmd2motorx);
    command1 = read_buffer_cmmd[0];
    if(command1 != 0)
    {
    	last_command1 = command1;
    	post_log("recv new cmmd", strlen("recv new cmmd"));
    	printf("new cmmdx :%c",command1);
    	fflush(stdout);
    }
    else
    {
    command1 = last_command1;
    
    }
    if(after_reset == 1)
    {
    after_reset=0;
    command1 = last_command1 = 's';
    
    }
    	//forward f
	if(command1 == 'd' && (position < X_MAX) )
	{
	if(motor_running)
	{
	position += STEP;
	
	real_position = (float)position/100;
	//printf("backwarding %f meter\n",real_position);
	rand_dt += (int)time(NULL);
	srand((int)time(NULL)*time(NULL)+rand_dt);
	err_ = rand()%5-2;
	
	position_estimated = position + err_;}
	sprintf(write_buffer_spec,"%d",position_estimated);
	//<send estimate position>
	int err = write(motorx2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	if(err<0)
	printf("write err %d",err);
	fflush(stdout);
   	//printf("write: %s\n",write_buffer_spec);
   	
	}
	// backward b
	else if(command1 == 'a' && (position > X_MIN) )
	{
	if(motor_running)
	{
	position -= (int)STEP;
	
	real_position = (float)position/100;
	// printf("backwarding %f meter\n",real_position);
	rand_dt += (int)time(NULL);
	srand((int)time(NULL)*time(NULL)+rand_dt);
	err_ = rand()%5-2;
	
	position_estimated = position + err_;}
	sprintf(write_buffer_spec,"%d",position_estimated);
	//<send estimate position>
	int err = write(motorx2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	if(err<0)
	printf("write err %d",err);
	fflush(stdout);
   	//printf("write: %s\n",write_buffer_spec);
   	
	}
	// stop s
	else if(command1 == 's' )
	{
	
	position_estimated = position;
	sprintf(write_buffer_spec,"%d",position_estimated);
	int err = write(motorx2spec,write_buffer_spec,strlen(write_buffer_spec)+1);
	if(err<0)
	printf("write err %d",err);
	fflush(stdout);
   	//printf("write: %s\n",write_buffer_spec);
	}

    
   	
   	//post_log("sent_motorx",sizeof("sent_motorx"));
   	//close(motorx2spec);


}

 } //end motorx




} 
//Function which creates and executes the two konsoles

int spawn(const char * program, char ** arg_list){
  pid_t child_pid = fork();
  if (child_pid != 0){
    return child_pid;
  } else {
    execvp (program, arg_list);
    perror("exec failed");
    return 1;
  }
}



int main() {
  


  //Only the watchdog channels must be always open, the other processes will open the channels on their own 

  //close(spec2w);
  //close(comm2w);


  char * arg_list_1[] = { "/usr/bin/konsole",  "-e", "./command_konsole",  (char*)NULL };
  char * arg_list_2[] = { "/usr/bin/konsole",  "-e", "./spec_konsole",  (char*)NULL };
  int pid1, pid2;

  pid1 = spawn("/usr/bin/konsole", arg_list_1);
  pid2 = spawn("/usr/bin/konsole", arg_list_2);


  //calling watchdog function

  watchdog();
 



	


}


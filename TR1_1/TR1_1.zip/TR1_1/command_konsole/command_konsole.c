#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <errno.h>
#include <sys/select.h>
#include <time.h>
#include <wait.h>

#define MSG 14


struct timeval time_for_ms;
void sleep_ms(unsigned int n)
{

 time_for_ms.tv_sec = 0;
      time_for_ms.tv_usec = n*1000;

      int ready = select(NULL, NULL, NULL, NULL, &time_for_ms);
}


char* log_file = "TR1_1/log/logARP1_cmmd.txt"; 
void post_log(char* data,int size)
{
if(size>50)
printf("log_size_overflow:%s\n ",data);
int fd_log = open(log_file,O_APPEND|O_WRONLY|O_CREAT);
if(fd_log ==-1)
{
  printf("fd_log open error");
  /* code */
}
else
{
 char logmsg[72] = "";
 unsigned int log_time = time(NULL);
 sprintf(logmsg,"info:%s,time:%d\n",data,log_time);
write(fd_log,logmsg,strlen(logmsg));
close(fd_log);
}
}

char message[MSG] = "";
char ch;
char tmp_str[10] = "";

int main(){

    int cmmd2motorx = -1;
    int cmmd2motorz = -1;
  
    char* myfifo_cmmd_motorx = "/tmp/cmmd2motorx";
    char* myfifo_cmmd_motorz = "/tmp/cmmd2motorz";


    mkfifo(myfifo_cmmd_motorx, 0666);
    mkfifo(myfifo_cmmd_motorz, 0666);
    cmmd2motorx = open(myfifo_cmmd_motorx, O_WRONLY|O_NONBLOCK);  //open write close
    cmmd2motorz = open(myfifo_cmmd_motorz, O_WRONLY|O_NONBLOCK);
    printf("\n\t\t\t\tCOMMAND KONSOLE\n\n\n\n\n");
    printf("Please press a button:\n\n");
    printf("\nj: increase height of z axis\n\nd: increase height of x axis\n");
    printf("\nl: decrease the height of z axis\n\na: decrease height of x axis\n");
    printf("\ns: stop motor_x\n\nk: stop motor_z\n");
    fflush(stdout);
    int running = 1;
    post_log("into while",sizeof("into while"));
while(running){
    if(cmmd2motorx<=0)
    cmmd2motorx = open(myfifo_cmmd_motorx, O_WRONLY|O_NONBLOCK);  //open write close
    if(cmmd2motorz<=0)
    cmmd2motorz = open(myfifo_cmmd_motorz, O_WRONLY|O_NONBLOCK);


    sleep_ms(20);
  //read command from console
  
  
fd_set rfds;
struct timeval tv;
int retval, m,n;
FD_ZERO(&rfds);
FD_SET(0, &rfds);
/* Wait up to five seconds. */
tv.tv_sec = 0;
tv.tv_usec = 10;
retval = select(1, &rfds, NULL, NULL, &tv);//mafd+1, readfds,writefds,errfds,timeval
if (retval == -1)
perror("select()");
else if (retval) {
/* FD_ISSET(0, &rfds) will be true. */
//n = read(0, line, 80);
 post_log("kbht ",sizeof("kbht"));
   
  printf("\n\t\t\033[1A"); 
  n = fgets(tmp_str, sizeof(tmp_str), stdin);
  ch = tmp_str[0];
  post_log("ch ",sizeof("ch "));
   post_log("judge ",sizeof("judge"));
  if (ch == 'd' ||  ch == 'a' || ch == 's' ){
    //tell motorx
	 post_log("x command1",sizeof("x command1"));
            sprintf(message,"%c ",ch);
             post_log(message,strlen(message));
            write(cmmd2motorx, message, strlen(message)+1);
           // close(cmmd2motorx);
            post_log("leave x command",sizeof("leave x command"));

  }
      else if (ch == 'j' ||  ch == 'k' || ch == 'l' ){
          // tell motorz
		post_log("z command",sizeof("z command"));
            
            sprintf(message,"%c",ch);
            write(cmmd2motorz, message, strlen(message)+1);
            post_log("leave z command",sizeof("leave z command"));
           // close(cmmd2motorz);

        }
//line[n] = '\0';
//m = write(1, line, n);
}

}

}





    
